#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2018/10/3 下午2:10
# @Author  : yuchangqian
# @Contact : changqian_yu@163.com
# @File    : __init__.py

from .syncbn import *
from .parallel import *